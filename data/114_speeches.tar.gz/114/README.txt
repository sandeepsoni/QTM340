These are the congressional speeches from the 114th session. 
The data is extracted from the dataset released by Gentzkow, Shapiro and Taddy.

Gentzkow, Matthew, Jesse M. Shapiro, and Matt Taddy. Congressional Record for the 43rd-114th Congresses: 
Parsed Speeches and Phrase Counts. Palo Alto, CA: Stanford Libraries [distributor], 2018-01-16.

Files
---

*speeches_114.txt: contains one speech per line
*114_SpeakerMap.txt: contains metadata for speakers

Please note that not all speech ids have an associated speaker.
